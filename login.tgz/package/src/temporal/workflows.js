/**
 * Availity login: OTP from Twilio webhook → otpStore → Temporal polling (30s) up to ~2 min.
 */
import {
  ApplicationFailure,
  log,
  proxyActivities,
  sleep,
  workflowInfo,
} from "@temporalio/workflow";

/** @typedef {{ outcome: string, pendingPath?: string, challengeUrl?: string, message?: string }} LoginAttemptResult */

const POLL_INTERVAL = "30s";
const MAX_POLL_ATTEMPTS = 5;

const { performLoginAttempt, submitOtpAndConfirm } = proxyActivities({
  startToCloseTimeout: "12 minutes",
  retry: {
    maximumAttempts: 4,
    initialInterval: "3s",
    backoffCoefficient: 2,
    maximumInterval: "45s",
  },
});

const { pollOtpFromStore } = proxyActivities({
  startToCloseTimeout: "30 seconds",
  retry: {
    maximumAttempts: 5,
    initialInterval: "1s",
    backoffCoefficient: 2,
    maximumInterval: "10s",
  },
});

const { runOhidLogin } = proxyActivities({
  startToCloseTimeout: "20 minutes",
  retry: {
    maximumAttempts: 1,
  },
});

/**
 * @param {Record<string, never>} _input
 * @returns {Promise<{ success: boolean }>}
 */
export async function availityLoginWorkflow(_input) {
  const workflowId = workflowInfo().workflowId;

  /** @type {LoginAttemptResult} */
  const attempt = await performLoginAttempt({ workflowId });

  if (attempt.outcome === "SUCCESS") {
    return { success: true };
  }

  if (attempt.outcome === "FAILURE") {
    throw ApplicationFailure.create({
      message: attempt.message ?? "Login failed",
      nonRetryable: true,
    });
  }

  if (attempt.outcome !== "OTP_REQUIRED" || !attempt.pendingPath) {
    throw ApplicationFailure.create({
      message: `Unexpected login outcome: ${attempt.outcome}`,
      nonRetryable: true,
    });
  }

  log.info("OTP required");
  log.info("Waiting for OTP");

  /** @type {string | undefined} */
  let otp;

  for (let i = 0; i < MAX_POLL_ATTEMPTS; i++) {
    const poll = await pollOtpFromStore({ workflowId });
    if (poll.found && poll.otp) {
      otp = poll.otp;
      break;
    }
    if (i === MAX_POLL_ATTEMPTS - 1) {
      break;
    }
    await sleep(POLL_INTERVAL);
  }

  if (!otp) {
    throw ApplicationFailure.create({
      message: "OTP not received within 2 minutes (Twilio / store)",
      nonRetryable: true,
    });
  }

  await submitOtpAndConfirm({
    otp,
    pendingPath: attempt.pendingPath,
    challengeUrl: attempt.challengeUrl ?? "",
    workflowId,
  });

  return { success: true };
}

/**
 * OHID login (Playwright) as a Temporal workflow.
 * This runs as a single activity on the worker: `runOhidLogin` (spawns `npm run login:ohid`).
 *
 * @param {{ runId?: string } | Record<string, never>} input
 * @returns {Promise<{ ok: true }>}
 */
export async function ohidLoginWorkflow(input) {
  const runId = typeof input?.runId === "string" ? input.runId : workflowInfo().workflowId;
  await runOhidLogin({ runId });
  return { ok: true };
}
