/**
 * Single process: HTTP API + Temporal worker (one terminal).
 * Starts both in parallel so the worker polls the task queue while the API accepts requests.
 */
import { pathToFileURL } from "node:url";
import { spawn } from "node:child_process";
import { PORT, startApiServer, printTemporalBanner } from "./api-server.js";
import { runWorker } from "./worker.js";

function shouldAutoStartOhidPlaywright() {
  const raw = process.env.AUTO_PLAYWRIGHT?.trim() ?? process.env.AUTO_START_PLAYWRIGHT?.trim();
  if (!raw) return false;
  return raw === "1" || raw.toLowerCase() === "true" || raw.toLowerCase() === "ohid";
}

function spawnOhidPlaywright() {
  if (globalThis.__AUTO_PLAYWRIGHT_STARTED__ === true) return;
  globalThis.__AUTO_PLAYWRIGHT_STARTED__ = true;

  const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
  const child = spawn(npmCmd, ["run", "login:ohid"], {
    stdio: "inherit",
    env: process.env,
    windowsHide: false,
  });

  child.on("error", (err) => {
    console.error("[Playwright] Failed to start OHID:", err instanceof Error ? err.message : String(err));
  });
}

/**
 * @param {{ nativeConnection?: import('@temporalio/worker').NativeConnection }} [opts]
 */
export async function runApp(opts = {}) {
  printTemporalBanner("starting");
  const apiPromise = startApiServer(PORT);
  const workerPromise = runWorker(
    opts.nativeConnection ? { nativeConnection: opts.nativeConnection } : {},
  );

  if (shouldAutoStartOhidPlaywright()) {
    // Non-blocking: run the browser flow in parallel with server/worker.
    // It will wait for US VPN egress before opening OHID (see src/ohid-login.ts).
    setTimeout(spawnOhidPlaywright, 250);
  }

  await Promise.all([apiPromise, workerPromise]);
}

const isDirectRun =
  process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isDirectRun) {
  runApp().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
